<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->

<!-- Bootstrap JavaScript (with Popper.js) -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->

<!-- Library Bundle Script -->
<script src="../assets/js/core/libs.min.js"></script>
<!-- External Library Bundle Script -->
<script src="../assets/js/core/external.min.js"></script>
<!-- Widgetchart Script -->
<script src="../assets/js/charts/widgetcharts.js"></script>
<!-- mapchart Script -->
<script src="../assets/js/charts/vectore-chart.js"></script>
<script src="../assets/js/charts/dashboard.js"></script>
<!-- fslightbox Script -->
<script src="../assets/js/plugins/fslightbox.js"></script>
<!-- Settings Script -->
<script src="../assets/js/plugins/setting.js"></script>
<!-- Slider-tab Script -->
<script src="../assets/js/plugins/slider-tabs.js"></script>
<!-- Form Wizard Script -->
<script src="../assets/js/plugins/form-wizard.js"></script>
<!-- AOS Animation Plugin-->
<script src="../assets/vendor/aos/dist/aos.js"></script>
<!-- App Script -->
<script src="../assets/js/hope-ui.js" defer></script>
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- src.js  -->
<script src="../assets/js/src.js"></script>
<!-- swal cdn -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
<!-- Include Flatpickr JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>