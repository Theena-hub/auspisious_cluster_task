<footer class="footer">
    <div class="footer-body justify-content-end">
        <div class="right-panel">
            ©
            <script>document.write(new Date().getFullYear())</script> Crackers Site Name
        </div>
    </div>
</footer>